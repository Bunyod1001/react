import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';


const text ="Hello Gropus"
const el = (
<div>
<h1 style={{color: "red"}}>Main:{text}</h1>
<input type="text" />
<button style={{color: "green", fontSize:"large" ,borderRadius:"40px", background:"yellow"}}>Submit</button>
</div>
 )


const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(el);
